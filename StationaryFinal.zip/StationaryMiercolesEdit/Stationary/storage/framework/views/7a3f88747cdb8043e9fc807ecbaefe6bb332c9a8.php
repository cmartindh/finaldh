<?php $__env->startSection('content'); ?>
  <br><br><br>
  <h3>Lista de Productos </h3>
  <br><br>

  <a href="/productos/nuevo">Agregar</a>

  <br><br><br>

  <ul>
    <?php $__currentLoopData = $losProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($producto->name."     $".$producto->price."    ".$producto->description); ?> <br>

		<img src="<?php echo e(\Storage::url($producto->image)); ?>" alt="">
      </li>

    <?php if( \Auth::user()->Admin == 1): ?>
    <ul>
        <li >
          <a href="<?php echo e(route('editar', [ 'id' => $producto->id ])); ?>">Editar</span></a><br>
          <a href="<?php echo e(route('borrar', [ 'id' => $producto->id ])); ?>">Borrar</span></a>
        </li>
    </ul>
  <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>