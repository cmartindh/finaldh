<?php $__env->startSection('content'); ?>
  <br><br><br>
  <h3>Lista de Productos </h3>
  <br><br>

  <a href="/productos/nuevo">Agregar</a>

  <br><br><br>


<!--Contenido de la categoría-->
<br><br>

<h2 class="cattitulo">Artículos para escritura</h2>

<div class="contcateg">
  <?php $__currentLoopData = $losProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="product"><img src="<?php echo e(\Storage::url($producto->image)); ?>" width="350" height="350">
      <br>
      <h3><?php echo e($producto->name); ?></h3>
      <br><hr><br>
      <p><?php echo e($producto->price); ?></p>
      <br><br>

      <br>
      <div class="botton"><a href="/productos/<?php echo e($producto->id); ?>">Ver detalle</a></div>
      <br>

       <?php if( \Auth::user() && \Auth::user()->Admin == 1): ?>
    
        <div class="botton"><a href="<?php echo e(route('editar', [ 'id' => $producto->id ])); ?>">Editar</span></a></div><br>
        <div class="botton"><a href="<?php echo e(route('borrar', [ 'id' => $producto->id ])); ?>">Borrar</span></a></div>
        </li>
    </ul>
  <?php endif; ?>

    </div>






     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






</div>
<br><br><br>


  <!--
  <ul>
    <?php $__currentLoopData = $losProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($producto->name."     $".$producto->price."    ".$producto->description); ?> <br>

		<img src="<?php echo e(\Storage::url($producto->image)); ?>" alt="">
      </li>

    if( \Auth::user()->Admin == 1)
    <ul>
        <li >
          <a href="<?php echo e(route('editar', [ 'id' => $producto->id ])); ?>">Editar</span></a><br>
          <a href="<?php echo e(route('borrar', [ 'id' => $producto->id ])); ?>">Borrar</span></a>
        </li>
    </ul>
  endif

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  -->
  <br><br>
<nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
     <li class="page-item disabled">
<?php echo e($losProductos->links()); ?>

</li>
  </ul>
</nav>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>