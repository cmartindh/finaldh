
<?php $__env->startSection('content'); ?>



<!--Formulario para cargar productos-->


<div class="nuevoproducto">
   
  <br>
      <form method="POST" enctype="multipart/form-data" action="/productos/editar/<?php echo e($producto->id); ?>">
  <?php echo e(csrf_field()); ?>

    <label for="">Nombre del Producto:</label>
    <input type="text" id="fname" name="name" value="<?php echo e(old('name')??$producto->name); ?>" >
    <br>


    <label for="lname">Descripción del producto en menos de 140 caracteres.</label>
    <input type="text" id="lname" name="description" value="<?php echo e(old('description')??$producto->description); ?> ">
    <br>


    <label for="">Categoría del producto</label>
    <select id="country" name="category">      
      <?php
       $categories = ['Escritura', 'Anotadores', 'Señaladores', 'Notas Adhesivas', 'Cintas y Stickers'];
      ?>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> {
        <option 
        <?php if($producto->category == $key): ?>
          selected = "selected"
        <?php endif; ?>
        value="<?php echo e($key); ?>"><?php echo e($key); ?></option>
      }
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
    </select>
    <br>


    <label for="">Precio</label>
    <input type="number" name="price" value="<?php echo e(old('price')??$producto->price); ?>">
      <br>


  <label for=""> Imagen </label>
  <input type="file" name="image" value="" multiple>



    <br><br>
    <input type="submit" value="Submit">
  </form>
</div>


<!--FIN DEL FORMULARIO-->

<br><br><br>

<?php $__env->stopSection(); ?>  




<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>