<?php $__env->startSection('content'); ?>





	<!--Detalles del prodcuto-->

		<div class="detalles">
			
			
			<div class="imagenprod"><img src="<?php echo e(\Storage::url($detalles->image)); ?>" width="500" height="500">
			<br><br>
			<p>Nuestros productos han sido testeados bajo los mejores controles de calidad en el mercado, por lo que aseguramos su durabilidad. </p>
			</div>


			<div class="productodt">
				<br>
				<h3><?php echo e($detalles->name); ?></h3>
				<br>
				<p><?php echo e($detalles->description); ?></p>
				<br><hr><br>
				<p><?php echo e("$".$detalles->price); ?></p>
				<br>
		
				<div class="botton"><a href="">Agregar al Carrito</a></div>
				<br>
				<br>
				<hr><br>
				<p><h4>Condiciones de envío</h4></p><br>
				<p>
					Los envíos puede realizarse mediante a los siguientes medios:</p><br>
				<p>
					-MercadoEnvíos. <br>
					-Correo Argentino. <br>
					-OCA. <br>
					-Correo Andreani. <br>
				</p>
				<br>

				<p class="moto">

					En el caso de requerir envío inmediato también ofrecemos servicio de moto mensajería a convenir con el cliente. Para acceder a este servicio por favor comuníquese con nosotros a nuestra casilla de <a href="mailto:StationaryStation@gmail.com">e-mail</a>.				

				</p>

			</div>

		</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>