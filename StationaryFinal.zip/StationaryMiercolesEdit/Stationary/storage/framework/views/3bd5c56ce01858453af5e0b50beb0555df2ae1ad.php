<!DOCTYPE html>
<html>
<head>
	<title>Stationary Station</title>
	  <meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="/css/estilos.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

		<nav>


			<ul>

				<li> <form class="example" action="action_page.php">
 			 <input type="text" placeholder="Search.." name="search">
 			 <button type="submit"><i class="fa fa-search"></i></button>
		</form></li>

				<li><a href="/productos/all">Home</a></li>
				<li><a href="#"><img src="/img/cart.png" class="carrito"></a></li>
				<?php if(auth()->guard()->guest()): ?>
						<li class="nav-item">
								<a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
						</li>
						<li class="nav-item">
								<a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
						</li>
				<?php else: ?>
						<li class="nav-item dropdown">
								<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
										<?php echo e(Auth::user()->name); ?> <span class="caret"></span>
								</a>

								<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
										<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
											 onclick="event.preventDefault();
																		 document.getElementById('logout-form').submit();">
												<?php echo e(__('Logout')); ?>

										</a>

										<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
												<?php echo csrf_field(); ?>
										</form>
								</div>
						</li>
				<?php endif; ?>
			</ul>

					<img src="/img/logo.png" class="logo">

		</nav>



			<!--Categorias-->
		<div class="categorias">
			<ul class="cats">
				<li><div class="caja"><a href="/Escritura">Escritura</a></div></li>
				<li><div class="caja"><a href="/Anotadores">Libros y Anotadores</a></div></li>
				<li><div class="caja"><a href="/Señaladores">Señaladores</a></div></li>
				<li><div class="caja"><a href="/Notas%20Adhesivas">Notas adhesivas</a></div></li>
				<li><div class="caja"><a href="/Cintas%20y%20Stickers">Cintas y Stickers</a></div></li>
			</ul>

	</div>


<?php echo $__env->yieldContent('content'); ?>





  <!--Footer-->

  <div class="footer">

    <div class="column">

      <img src="/img/twitter.png">
      <img src="/img/instagram.png">
      <img src="/img/facebook.png">

    </div>


    <div class="column">
      <p>
        <br>
        Envianos un mail a <a href="mailto:StationaryStation@gmail.com">StationaryStation@gmail.com</a>
      </p>
    </div>

  </div>




  </div> <!--Contenedor-->
</body>
</html>
