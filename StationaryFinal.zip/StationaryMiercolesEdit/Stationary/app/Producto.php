<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class producto extends Model
{
    protected $guarded = [];
    

     public $timestamps = false;

    // protected $table = 'productos';


}
