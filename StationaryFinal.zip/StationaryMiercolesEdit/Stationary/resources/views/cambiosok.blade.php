@extends('layouts.layout')
@section('content')


<h2>Se guardaron los cambios en el producto!</h2>

<a href="/productos/all">Volver a todos los productos</a>


@endsection