@extends('layouts.layout')
@section('content')



<!--Formulario para cargar productos-->


<div class="nuevoproducto">
   
   <div class="bloque">
  <br>
      <form method="POST" enctype="multipart/form-data" action="/productos/editar/{{$producto->id}}" id="editar">
  {{ csrf_field() }}
    <label for="">Nombre del Producto:</label>
    <input type="text" id="fname" name="name" value="{{old('name')??$producto->name}}" >
    <br>
  <div></div>
  </div>


    <div class="bloque">
    <label for="lname">Descripción del producto en menos de 140 caracteres.</label>
    <input type="text" id="lname" name="description" value="{{old('description')??$producto->description}} ">
    <br>
      <div></div>
  </div>


<div class="bloque">

    <label for="">Categoría del producto</label>
    <select id="country" name="category">      
      @php
       $categories = ['Escritura', 'Anotadores', 'Señaladores', 'Notas Adhesivas', 'Cintas y Stickers'];
      @endphp
      @foreach ($categories as $key) {
        <option 
        @if ($producto->category == $key)
          selected = "selected"
        @endif
        value="{{$key}}">{{$key}}</option>
      }
      @endforeach      
    </select>
    <br>
      <div></div>
  </div>


  <div class="bloque">
    <label for="">Precio</label>
    <input type="number" name="price" value="{{old('price')??$producto->price}}">
      <br>
        <div></div>
  </div>

  <div class="bloque">
  <label for=""> Imagen </label>
  <input type="file" name="image" value="" multiple>
       <div></div>
  </div>



    <br><br>
    <input type="submit" value="Submit">
  </form>
</div>


<!--FIN DEL FORMULARIO-->

<script src="/js/editar.js"></script>

<br><br><br>

@endsection  



