@extends('layouts.layout')
@section('content')
  <br><br><br>


  <center><a href="/productos/nuevo"><b>Agregar un producto</b></a></center>

  <br><br><br>


<!--Contenido de la categoría-->


<div class="contcateg">
  @foreach ($losProductos as $producto)
    <div class="product"><img src="{{\Storage::url($producto->image)}}" width="350" height="350">
      <br>
      <h3>{{$producto->name}}</h3>
      <br><hr><br>
      <p>{{$producto->price}}</p>
      <br><br>

      <br>
      <div class="botton"><a href="/productos/{{$producto->id}}">Ver detalle</a></div>
      <br>

       @if( \Auth::user() && \Auth::user()->Admin == 1)
    
        <div class="botton"><a href="{{route('editar', [ 'id' => $producto->id ])}}">Editar</span></a></div><br>
        <div class="botton"><a href="{{route('borrar', [ 'id' => $producto->id ])}}">Borrar</span></a></div>
        </li>
    </ul>
  @endif

    </div>




    @endforeach






</div>
<br><br><br>


  <!--
  <ul>
    @foreach ($losProductos as $producto)
      <li>{{$producto->name."     $".$producto->price."    ".$producto->description}} <br>

		<img src="{{\Storage::url($producto->image)}}" alt="">
      </li>

    if( \Auth::user()->Admin == 1)
    <ul>
        <li >
          <a href="{{route('editar', [ 'id' => $producto->id ])}}">Editar</span></a><br>
          <a href="{{route('borrar', [ 'id' => $producto->id ])}}">Borrar</span></a>
        </li>
    </ul>
  endif

    @endforeach
  </ul>
  -->
  <br><br>
<nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
     <li class="page-item disabled">
{{ $losProductos->links() }}
</li>
  </ul>
</nav>



@endsection
