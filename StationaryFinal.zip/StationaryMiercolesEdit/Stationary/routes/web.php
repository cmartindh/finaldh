<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'ProductsController@get');

Route::get('/home', 'ProductsController@get');


/*Desde acá van todas las vistas con controlador ProductsController*/

Route::prefix('/productos')->group( function(){


	Route::get('/all', 'ProductsController@get')->name('all');


	Route::get('/nuevo', function () {
	    return view('nuevoproducto');
	});

	Route::post('/nuevo', 'ProductsController@guardar');



	/*Rutas a controlador para editar y guardar cambios del producto*/
	Route::get('/editar/{id}', 'ProductsController@editar')->name('editar');
	Route::post('/editar/{id}', 'ProductsController@guardarCambios');


	/*Ruta para borrar un producto*/
	Route::get('borrar/{id}', 'ProductsController@borrar')->name('borrar');

	/*Ruta con detalle de producto*/
	Route::get('/{id}','ProductsController@detalle')->name('detalle');

});

Route::get('/contador','ProductsController@contadorUsuarios');



Route::get('/cambiosok', function () {
    return view('cambiosok');
});

Route::get('/faq', function () {
    return view('faq');
});

Route::get('/categoria', function () {
    return view('categoria');
});



Route::get('/vistaproducto', function () {
    return view('vistaproducto');
});

Auth::routes();

// Route::get('/home', 'HomeController@index')->name('home');


/*Acá van las rutas para las categorias*/

Route::get('/{category}', 'ProductsController@mostrarCategoria');
