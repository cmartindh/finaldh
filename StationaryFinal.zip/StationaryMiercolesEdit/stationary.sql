-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: stationary
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.26-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2018_10_12_000000_create_productos_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (5,'ad',123,'feqfqw','/productos/default.jpg','Anotadores',NULL,NULL),(6,'dff',543,'feqfqw','/productos/default.jpg','Anotadores',NULL,NULL),(7,'gfd',5654,'feqfqw','/productos/default.jpg','Anotadores',NULL,NULL),(8,'gf',765,'feqfqw','/productos/default.jpg','Escritura',NULL,NULL),(9,'erwr',3,'feqfqw','/productos/default.jpg','Escritura',NULL,NULL),(10,'dgfdgfds',97,'feqfqw','/productos/default.jpg','Escritura',NULL,NULL),(11,'jhgj',98678,'feqfqw','/productos/default.jpg','Escritura',NULL,NULL),(12,'jdgj',756,'feqfqw','/productos/default.jpg','Escritura',NULL,NULL),(13,'jtws',3542,'feqfqw','/productos/default.jpg','Escritura',NULL,NULL),(14,'wgfv',63546,'feqfqw','/productos/default.jpg','Escritura',NULL,NULL),(15,'bdfg',563,'feqfqw','/productos/default.jpg','Escritura',NULL,NULL),(17,'asfasd',20,'fasdsa','productos/fbPZhE9dmak20QaWS7GXe5FfmEYSrUM1FPwZJgPm.png','Señaladores',NULL,NULL),(18,'gfhfgh',60,'kghj','productos/PIyBsYgsYszjGbI3kn6KmS3JUX6DAeHOwDvYUL6g.png','Notas Adhesivas',NULL,NULL),(21,'Marcadorcitohhhh',20,'sdasd','/productos/default.jpg','Escritura',NULL,NULL);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Admin` int(11) NOT NULL DEFAULT '0',
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Shina','shina@gmail.com','$2y$10$K6/KiHahuFZm7gk1njTyEeJhNVeNKx5OXLn6n7h82V2zzAzYohNrm',1,NULL,'Bj5zhckb3jVyot82CrgHNJmpyk5omZ6KfoVshUbpK3tqf2vi4TvMjbsYFIwK','2018-08-07 02:53:03','2018-08-07 02:53:03'),(2,'Momi','momi@momi.com','$2y$10$76C.aW4wNt/QZcwJZhjL5.liyRdNrxFtmxWkFevRledkeFgUiKku6',0,NULL,'nWThM166mGnSj8FeLnXEEkQTm9wSZqYPwkHo8uZB6jMH833NtVdw0vZDmwUg','2018-08-09 04:22:12','2018-08-09 04:22:12'),(3,'Carolinaaa','lalsa@gmail.com','$2y$10$9zeA1zsguj2D2t7BvlJDK.o6So4ocH2uKv3PWSR3a9lA0XWa.73h2',0,'37787566_274168726689670_6134450386708201472_n.jpg','9gU6LKumNuhKqMXF2q0jUKo7HQKlJ8JnRTshjTT8IlYXugv1lApDb9ZeD0pt','2018-08-09 05:20:05','2018-08-09 05:20:05'),(4,'asd','asd@asd.com','$2y$10$vRBuW/acVBgAx4QdYvmc4O4Ab6fWT7IVpEXtITZd0pMwfBcR3ivIK',0,'Blurry_Trees.jpg','Gd021yxNZ7oDxCmnCQ6qgDBX8wzscJxfmjP96rNbwfsoxlBiEqBdhgEhUpLk','2018-08-09 05:37:49','2018-08-09 05:37:49'),(5,'qwe','qwe@qwe.com','$2y$10$YmRdfmJ07q0ANQQfFUFkmuwaMSFEOHb1qy5cwXZGszHjpjbSbq5SW',0,'C:\\xampp\\tmp\\phpBD87.tmp','mjAiIBV2tQyaWFapOpxO7qOCEmHrUkuRr5CSw5LiQVc4e9670oVK8L1v37WU','2018-08-09 05:47:57','2018-08-09 05:47:57'),(6,'iop','iop@iop.com','$2y$10$8qxbHYPD1k9yb/w.cVYnrOM1hVEYNkC5OLggnrKL.olEjqYsPejiW',0,'avatares/1v3IRA7AZA2W3QLLLYjCYAYNhKTgLYvOHzz0gpjy.png','HWZnF20w5LYr23oU5ruFVfYnsHMb5lROhjSrLGmaqbQ4BCPCYL6ykuCSAYBX','2018-08-09 05:50:47','2018-08-09 05:50:47');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'stationary'
--

--
-- Dumping routines for database 'stationary'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-09  0:29:16
