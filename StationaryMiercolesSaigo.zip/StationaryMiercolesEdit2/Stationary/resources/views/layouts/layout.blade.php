<!DOCTYPE html>
<html>
<head>
	<title>Stationary Station</title>
	  <meta charset="UTF-8">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" type="text/css" href="/css/<?= (isset($_COOKIE['css']) && ($_COOKIE['css'] == 'estilosdark'))? 'estilosdark' : 'estilos' ?>.css" id="theme_css" >

</head>
<body id="body" class="dark-mode">

		<nav>


			<ul>

				<li> <form class="example" action="action_page.php">
 			 <input type="text" placeholder="Search.." name="search">
 			 <button type="submit"><i class="fa fa-search"></i></button>
		</form></li>

				<li><a href="/productos/all">Home</a></li>
				<li><a href="#"><img src="/img/cart.png" class="carrito"></a></li>
				@guest
						<li class="nav-item">
								<a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
						</li>
						<li class="nav-item">
								<a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
						</li>
				@else
						<li class="nav-item dropdown">
								<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
										{{ Auth::user()->name }} <span class="caret"></span>
								</a>

								<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
										<a class="dropdown-item" href="{{ route('logout') }}"
											 onclick="event.preventDefault();
																		 document.getElementById('logout-form').submit();">
												{{ __('Logout') }}
										</a>

										<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
												@csrf
										</form>
								</div>
						</li>
				@endguest
			</ul>

					<img src="/img/logo.png" class="logo">

		</nav>



			<!--Categorias-->
		<div class="categorias">
			<ul class="cats">
				<li><div class="caja"><a href="/Escritura">Escritura</a></div></li>
				<li><div class="caja"><a href="/Anotadores">Libros y Anotadores</a></div></li>
				<li><div class="caja"><a href="/Señaladores">Señaladores</a></div></li>
				<li><div class="caja"><a href="/Notas%20Adhesivas">Notas adhesivas</a></div></li>
				<li><div class="caja"><a href="/Cintas%20y%20Stickers">Cintas y Stickers</a></div></li>
			</ul>

	</div>

	<!--Slider con productos -->
	 <div class="slider">

		 <div class="slider-container">
		<div class="menu">
			<label for="slide-dot-1"></label>
			<label for="slide-dot-2"></label>
			<label for="slide-dot-3"></label>
		</div>

		<input id="slide-dot-1" type="radio" name="slides" checked>
			<div class="slide slide-1"></div>

		<input id="slide-dot-2" type="radio" name="slides">
			<div class="slide slide-2"></div>

		<input id="slide-dot-3" type="radio" name="slides">
			<div class="slide slide-3"></div>
	</div>



	<br><br>
	<center>Somos<div class="contador" id="contador"></div>usuarios!</center>
<br><br>
	 <center><button type="button" id="theme">Cambiar Tema</button></center>

@yield('content')





  <!--Footer-->

  <div class="footer" id="footer">

    <div class="column">

      <img src="/img/twitter.png">
      <img src="/img/instagram.png">
      <img src="/img/facebook.png">

    </div>


    <div class="column">
      <p>
        <br>
        Envianos un mail a <a href="mailto:StationaryStation@gmail.com">StationaryStation@gmail.com</a>
      </p>
			<br>
				<a href="/faq">Preguntas Frequentes</a>
    </div>

  </div>




  </div> <!--Contenedor-->
  <script src="/js/toggle.js"></script>
	  <script src="/js/agregar.js"></script>
	   <script src="/js/contador.js"></script>

</body>

</html>
