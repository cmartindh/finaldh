
@extends('layouts.layout')




@section('content')



	<!--Detalles del prodcuto-->

		<div class="detalles">


			<div class="imagenprod"><img src="{{\Storage::url($detalles->image)}}" width="500" height="500">
			<br><br>
			<p>Nuestros productos han sido testeados bajo los mejores controles de calidad en el mercado, por lo que aseguramos su durabilidad. </p>
			</div>


			<div class="productodt">
				<br>
				<h3>{{$detalles->name}}</h3>
				<br>
				<p>{{$detalles->description}}</p>
				<br><hr><br>
				<p>{{"$".$detalles->price}}</p>
				<br>

				<div class="botton"><a href="">Agregar al Carrito</a></div>
				<br>
				<br>
				<hr><br>
				<p><h4>Condiciones de envío</h4></p><br>
				<p>
					Los envíos puede realizarse mediante a los siguientes medios:</p><br>
				<p>
					-MercadoEnvíos. <br>
					-Correo Argentino. <br>
					-OCA. <br>
					-Correo Andreani. <br>
				</p>
				<br>

				<p class="moto">

					En el caso de requerir envío inmediato también ofrecemos servicio de moto mensajería a convenir con el cliente. Para acceder a este servicio por favor comuníquese con nosotros a nuestra casilla de <a href="mailto:StationaryStation@gmail.com">e-mail</a>.

				</p>

			</div>

		</div>




@endsection
