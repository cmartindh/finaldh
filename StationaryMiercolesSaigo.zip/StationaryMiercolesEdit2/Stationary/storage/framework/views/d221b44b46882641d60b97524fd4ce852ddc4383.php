<?php $__env->startSection('content'); ?>

<!--Contenido de la categoría-->
<br><br>

<h2 class="cattitulo">Artículos para escritura</h2>

<div class="contcateg">
	
		<div class="product"><img src="img/1.jpg" width="350" height="350">
			<br>
			<h3>Marcadores Copic Neón</h3>
			<br><hr><br>
			<p>Precio: $90</p>
			<br>
			<div class="botton"><a href="vistaproducto">Ver detalle</a></div>
		</div>

		<div class="product"><img src="img/2.jpg" width="350" height="350">
			<br>
			<h3>Marcador Copic Intense</h3>
			<br><hr><br>
			<p>Precio: $90</p>
			<br>
			<div class="botton"><a href="vistaproducto">Ver detalle</a></div>
		</div>

		<div class="product"><img src="img/3.jpg" width="350" height="350">
		<br>
		<h3>Marcador Copic doble punta </h3>
		<br><hr><br>
		<p>Precio: $100</p>
		<br>
		<div class="botton"><a href="vistaproducto">Ver detalle</a></div>
		</div>

		<div class="product"><img src="img/4.jpg" width="350" height="350">
		<br>
		<h3>Copic Blender doble punta</h3>
		<br><hr><br>
		<p>Precio: $120</p>
		<br>
		<div class="botton"><a href="vistaproducto">Ver detalle</a></div>
		</div>

		<div class="product"><img src="img/5.jpg" width="350" height="350">
		<br>
		<h3>Caja de Copic Sketch</h3>
		<br><hr><br>
		<p>Precio: $1000</p>
		<br>
		<div class="botton"><a href="vistaproducto">Ver detalle</a></div>
		</div>

		<div class="product"><img src="img/6.jpg" width="350" height="350">
		<br>
		<h3>Pilot ballpen</h3>
		<br><hr><br>
		<p>Precio: $35</p>
		<br>
		<div class="botton"><a href="vistaproducto">Ver detalle</a></div>
		</div>

		<div class="product"><img src="img/7.jpg" width="350" height="350">
		<br>
		<h3>Pilot Hi-tech point </h3>
		<br><hr><br>
		<p>Precio: $50</p>
		<br>
		<div class="botton"><a href="vistaproducto">Ver detalle</a></div>
		</div>


		<div class="product"><img src="img/8.jpg" width="350" height="350">
		<br>
		<h3>Lapicera</h3>
		<br><hr><br>
		<p>Precio: $60</p>
		<br>
		<div class="botton"><a href="vistaproducto">Ver detalle</a></div>
		</div>





</div>
<br><br><br>


<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>