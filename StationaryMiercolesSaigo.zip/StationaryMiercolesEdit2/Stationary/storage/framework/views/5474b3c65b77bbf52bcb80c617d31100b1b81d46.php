<?php $__env->startSection('content'); ?>

<!--Formulario para cargar productos-->


<div class="nuevoproducto">

	<br>
  <form method="POST" enctype="multipart/form-data" action="/productos/nuevo" id="agregar">
	<?php echo e(csrf_field()); ?>

	<div class="bloque">


    <label for="">Nombre del Producto:</label>
    <input type="text" id="fname" name="name" value="<?php echo e(old('name')); ?>" >
		<br>
		<div></div>
	</div>

<div class="bloque">
    <label for="lname">Descripción del producto en menos de 140 caracteres.</label>
    <input type="text" id="lname" name="description" value="<?php echo e(old('description')); ?> ">
		<br>
			<div></div>
</div>

<div class="bloque">
    <label for="">Categoría del producto</label>
    <select id="country" name="category">
      <option value="Escritura">Elegir categoría</option>
      <option value="Escritura">Escritura</option>
      <option value="Anotadores">Anotadores</option>
      <option value="Señaladores">Señaladores</option>
      <option value="Notas Adhesivas">Notas Adhesivas</option>
      <option value="Cintas y Stickers">Cintas y Stickers</option>
    </select>
		<br>
			<div></div>
			<br>
		</div>


<div class="bloque">
    <label for="">Precio</label>
    <input type="number" name="price" value="<?php echo e(old('price')); ?>">
    	<br>
			<div></div><br>
		</div>


<div class="bloque">
	<label for=""> Imagen </label>
	<input type="file" name="image" value="image" multiple>
    <div></div><br>
    </div>



		<br><br>
    <input type="submit" value="Submit">
  </form>
</div>


<!--FIN DEL FORMULARIO-->


<script src="/js/agregar.js"></script>



<br><br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>