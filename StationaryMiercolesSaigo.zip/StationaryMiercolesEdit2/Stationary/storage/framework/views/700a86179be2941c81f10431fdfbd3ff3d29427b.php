<?php $__env->startSection('content'); ?>


<h2>Se guardaron los cambios en el producto!</h2>

<a href="/productos/all">Volver a todos los productos</a>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>