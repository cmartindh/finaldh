// window.setInterval(pedro,1000);

// function pedro(){
// 	document.getElementById('contador').innerHTML='Somos tantos!';

// 	  // Set request
//     //var request = $.get('/productos/all');

//     alert('request');

// }


function actualizarContador(){

  fetch('http://localhost:8000/contador')
    .then(function (response) {
      return response.json();
    })
    .then(function (respFinal) {
      var span=document.getElementById('contador')
      span.innerHTML = respFinal;
      console.log(respFinal);
    })
    .catch(function (error) {
      console.error(error);
    })

}

window.onload=function(){

  actualizarContador();

  var intervalo = setInterval(actualizarContador,30000);
}