document.getElementById('theme').onclick = function () {
    var actual = document.getElementById('theme_css').href;
    if (actual.includes('dark')) {
    	  document.getElementById('theme_css').href = '/css/estilos.css';
        document.cookie = 'css=estilos;path=/';
        console.log(document.cookie)
    } else {
    	  document.getElementById('theme_css').href = '/css/estilosdark.css';
        document.cookie = 'css=estilosdark;path=/';
        console.log(document.cookie)
    }

};
