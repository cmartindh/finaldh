window.addEventListener('load', function () {


	var form = document.querySelector('#editar');

  var misCampitos = form.elements;
  misCampitos = Array.from(misCampitos);
  misCampitos.pop();

  for (var campito of misCampitos) {
    campito.addEventListener('blur',function(){
      //el event listner se fija si algo se ejecuta en cada campito
      if (this.type == 'file') { return;}
      
      if (this.value.trim() === '' || this.selectedIndex ===0) {
        this.classList.add('is-invalid');
        this.parentNode.querySelector('div').classList.add('error');
        this.parentNode.querySelector('div').innerHTML = 'Este campo es <b>obligatorio</b>';
      } else {
        this.classList.remove('is-invalid');
        this.parentNode.querySelector('div').classList.remove('error');
        this.parentNode.querySelector('div').innerHTML = '';
      }
    });

  };





  form.onsubmit = function (ev) {
     var e = document.getElementById("country");
    if (
      e.selectedIndex ===0 ||
      misCampitos[0].value.trim() === '' ||
      misCampitos[1].value.trim() === '' ||
      misCampitos[2].value === '' ||
      misCampitos[3].value === '' ||
      !regexEmail.test(inputEmail.value)
    ) {
      ev.preventDefault();
      window.alert('Completa todos los campos');
    }
  }
});
