window.onload = function () {

	var form = document.querySelector('#register');

  var misCampitos = form.elements;
  misCampitos = Array.from(misCampitos);
  misCampitos.pop();

  for (var campito of misCampitos) {
    campito.addEventListener('blur',function(){
      //el event listner se fija si algo se ejecuta en cada campito
      if (this.value.trim() === '') {
        this.classList.add('is-invalid');
        this.parentNode.querySelector('div').classList.add('error');
        this.parentNode.querySelector('div').innerHTML = 'Este campo es <b>obligatorio</b>';
      } else {
        this.classList.remove('is-invalid');
        this.parentNode.querySelector('div').classList.remove('error');
        this.parentNode.querySelector('div').innerHTML = '';
      }
    });

  };



  var regexEmail = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;

  var inputEmail = form.querySelector('input[name=email]');

  inputEmail.addEventListener('blur', function () {
    if (!regexEmail.test(this.value)) {
      this.classList.add('is-invalid');
      this.parentNode.querySelector('div').classList.add('error');
      this.parentNode.querySelector('div').innerHTML = 'Ingresá un formato de <b>email valido</b>';
    } else {
      this.classList.remove('is-invalid');
      this.parentNode.querySelector('div').classList.remove('error');
      this.parentNode.querySelector('div').innerHTML = '';
    }
  });

  form.onsubmit = function (ev) {
    if (
      misCampitos[0].value.trim() === '' ||
      misCampitos[2].value.trim() === '' ||
      !regexEmail.test(inputEmail.value)
    ) {
      ev.preventDefault();
      window.alert('Completa todos los campos');
    }
  }
}
