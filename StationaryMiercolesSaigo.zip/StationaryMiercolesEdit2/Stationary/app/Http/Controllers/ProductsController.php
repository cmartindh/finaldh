<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Producto;
use App\User;
class ProductsController extends Controller
{
    public function get(){
      //$productosLista = Producto::all();
      $productosLista = Producto::paginate(5);
      return view('products')->with('losProductos',$productosLista);
    }

    /*Acá va el método para guardar un producto nuevo en base de datos*/
    public function guardar(Request $request){
      if ($request->file('image')) {
        $rutaImg=$request->file('image')->store('productos', 'public');
      }else {
        $rutaImg='/productos/default.jpg';
      }
        $reglas=[
          'name'=>'required',
          'description'=>'required',
          'price'=>'required',
          'category'=>'required',
          'image'=>'image',
        ];
        $mensajes=[
          'required'=>'No completaste este campo'
        ];
        $this->validate($request, $reglas, $mensajes);
        $producto=Producto::create(
            $request->except(['_token'])
          );
        $producto->image=$rutaImg;
        $producto->save();
          return redirect('/productos/all');

    }

      /*Acá va el método para editar los cambios del producto*/
      public function editar($id){
      $producto=Producto::find($id);
      return view('/editar')
      ->with('producto',$producto);
    }

    /*Acá va el método para guardar los cambios */

      public function guardarCambios($id, Request $request){

        $producto=Producto::find($id);

        if ($request->file('image')) {
        $rutaImg=$request->file('image')->store('productos', 'public');
      }else {
        $rutaImg= $producto->image;
      }



        $producto->fill($request->except(['_token']));



        $producto->image=$rutaImg;

        $producto->save();

        return view('/cambiosok');
      }

    /*Acá va el método para borrar un producto*/
    public function borrar($id){
        $producto= Producto::find($id);
        $producto->delete();
        return redirect('/productos/all');
      }

    /*Acá va el método que muestra la categoría*/
    public function mostrarCategoria($category){
     $productosLista = Producto::where('category', $category)->paginate('3');
     //Con esto traigo todas las caterogias que sean escritura
      return view('products')->with('losProductos',$productosLista);
      /*En la vista products me envia productos lista con los parametros*/
    }
    /*Acá va el método para ver el detalle de producto por su id*/
    public function detalle($id){
       $producto= Producto::find($id);
       return view('vistaproducto')->with('detalles',$producto);
     }
/*Acá el método me trae la api contador desde mi base de datos*/
 public function contadorUsuarios(){
        $resp =User::count();
        return response()->json($resp);
      }
}
